# ----------------------------------------------------------------
# SUNDIALS Copyright Start
# Copyright (c) 2002-2024, Lawrence Livermore National Security
# and Southern Methodist University.
# All rights reserved.
#
# See the top-level LICENSE and NOTICE files for details.
#
# SPDX-License-Identifier: BSD-3-Clause
# SUNDIALS Copyright End
# ----------------------------------------------------------------
sundials_version = 'v7.0.0'
arkode_version = 'v6.0.0'
cvode_version = 'v7.0.0'
cvodes_version = 'v7.0.0'
ida_version = 'v7.0.0'
idas_version = 'v6.0.0'
kinsol_version = 'v7.0.0'
year = '2024'
